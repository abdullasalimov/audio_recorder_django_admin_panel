# python35
Audio recorder

##Login:
- User: admin
- Pass: admin

##Activate Env
```
source bin/activate
```

##Run the server

Change to the project directory
```
cd mysite
```

then run the server
```
python manage.py runserver
````
